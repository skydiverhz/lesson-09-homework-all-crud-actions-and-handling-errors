# Lesson 09 Homework

## Install Instructions

1) Fork and Clone this repository according to the tutorial found [here](https://github.com/BE101KG/homework-assignment-instructions/blob/master/git_github_tutorial.pdf)

2) Navigate to the app folder using the command line

3) Once inside the app folder, run the following
 - ``bundle install``
 - ``bundle exec rake db:migrate``
 
**DO NOT RUN ``rails new [project name]``** - this command has already been run on your behalf (as evidenced by the already generated rails project folders)
